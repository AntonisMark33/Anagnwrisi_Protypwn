import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import StratifiedShuffleSplit, KFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error, mean_absolute_error


# 1. Φόρτωση Δεδομένων
def load_data(file_path: str):
    return pd.read_csv(file_path)


data_frame = load_data("housing.csv")

# 2. Δημιουργία Δυαδικού Στόχου για τον Perceptron
median_value_threshold = data_frame["median_house_value"].median()
data_frame["target_class"] = (data_frame["median_house_value"] > median_value_threshold).astype(int)

# 3. Χαρακτηριστικά για Προεπεξεργασία
numeric_attributes = ['longitude', 'latitude', 'housing_median_age', 'total_rooms',
                      'total_bedrooms', 'population', 'households', 'median_income']
categorical_attributes = ['ocean_proximity']

# 4. Preprocessing Pipelines
numerical_transform = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

categorical_transform = Pipeline([
    ('imputer', SimpleImputer(strategy='most_frequent')),
    ('encoder', OneHotEncoder(handle_unknown='ignore'))
])

data_transformer = ColumnTransformer([
    ('numeric', numerical_transform, numeric_attributes),
    ('categorical', categorical_transform, categorical_attributes)
])

# 5. Οπτικοποίηση Δεδομένων
plt.figure(figsize=(10, 8))
sns.heatmap(data_frame.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Χάρτης Συσχέτισης Μεταβλητών")
plt.show()

plt.figure(figsize=(8, 6))
sns.scatterplot(x=data_frame["median_income"], y=data_frame["median_house_value"], alpha=0.5)
plt.xlabel("Median Income")
plt.ylabel("Median House Value")
plt.title("Εισόδημα vs. Τιμή Ακινήτου")
plt.show()

# 6. Σωστό Stratified Train-Test Split
split = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
for train_index, test_index in split.split(data_frame, data_frame["target_class"]):
    strat_train_set = data_frame.loc[train_index]
    strat_test_set = data_frame.loc[test_index]

X_train = strat_train_set[numeric_attributes + categorical_attributes]
y_train = strat_train_set["median_house_value"]
X_test = strat_test_set[numeric_attributes + categorical_attributes]
y_test = strat_test_set["median_house_value"]


# 7. Υλοποίηση Perceptron
class PerceptronCustom:
    def __init__(self, learning_rate=0.01, epochs=1000):
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.weights = None
        self.bias = None

    def fit(self, X, y):
        X = X.to_numpy()
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0

        for _ in range(self.epochs):
            for i in range(n_samples):
                linear_output = np.dot(X[i], self.weights) + self.bias
                y_pred = 1 if linear_output >= 0 else 0
                update = self.learning_rate * (y[i] - y_pred)
                self.weights += update * X[i]
                self.bias += update

    def predict(self, X):
        X = X.to_numpy()
        linear_output = np.dot(X, self.weights) + self.bias
        return np.where(linear_output >= 0, 1, 0)


# 8. Υλοποίηση Least Squares Regression
class LeastSquaresRegression:
    def __init__(self):
        self.weights = None

    def fit(self, X, y):
        X = X.to_numpy()
        y = y.to_numpy()
        X_b = np.c_[np.ones((X.shape[0], 1)), X]  # Προσθήκη bias
        self.weights = np.linalg.inv(X_b.T.dot(X_b)).dot(X_b.T).dot(y)  # Υπολογισμός βαρών

    def predict(self, X):
        X = X.to_numpy()
        X_b = np.c_[np.ones((X.shape[0], 1)), X]  # Προσθήκη bias
        return X_b.dot(self.weights)


# 9. Εκπαίδευση και Αξιολόγηση Μοντέλων
def train_and_evaluate_model(model, X_train, y_train, X_test, y_test):
    model.fit(X_train, y_train)
    train_predictions = model.predict(X_train)
    test_predictions = model.predict(X_test)

    train_mse = mean_squared_error(y_train, train_predictions)
    test_mse = mean_squared_error(y_test, test_predictions)
    train_mae = mean_absolute_error(y_train, train_predictions)
    test_mae = mean_absolute_error(y_test, test_predictions)

    return train_mse, test_mse, train_mae, test_mae


# Perceptron Training
perceptron_model = PerceptronCustom(learning_rate=0.01, epochs=1000)
perceptron_results = train_and_evaluate_model(perceptron_model, X_train, strat_train_set["target_class"], X_test,
                                              strat_test_set["target_class"])
print("Perceptron - Εκπαίδευση MSE:", perceptron_results[0])
print("Perceptron - Δοκιμή MSE:", perceptron_results[1])

# Linear Regression Training
linear_model = LeastSquaresRegression()
linear_results = train_and_evaluate_model(linear_model, X_train, y_train, X_test, y_test)
print("Γραμμική Παλινδρόμηση - Εκπαίδευση MSE:", linear_results[0])
print("Γραμμική Παλινδρόμηση - Δοκιμή MSE:", linear_results[1])


# 10. Cross-Validation
def cross_validate_custom(model, X, y, n_splits=10):
    kfold = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    mse_scores = []

    for train_idx, test_idx in kfold.split(X):
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        mse_scores.append(mean_squared_error(y_test, y_pred))

    return np.mean(mse_scores)


# Perceptron Cross-Validation
perceptron_cv_mse = cross_validate_custom(perceptron_model, X_train, strat_train_set["target_class"])
print("Perceptron - Μέσος Όρος CV MSE:", perceptron_cv_mse)

# Linear Regression Cross-Validation
linear_cv_mse = cross_validate_custom(linear_model, X_train, y_train)
print("Γραμμική Παλινδρόμηση - Μέσος Όρος CV MSE:", linear_cv_mse)