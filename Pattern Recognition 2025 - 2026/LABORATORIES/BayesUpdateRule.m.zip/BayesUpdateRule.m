% This script file simulates the Bays updating rule in the context of a
% cancer test.

% Consider the following a priori class probabilities:
% (i): Pc(0) = P(Cancer), the a-priori probabibility that a randomly  
%                         selected person has cancer.
% (ii): P(NoCancer) = 1 - Pc(0), the a-priori probability that a randomly
%                                selected person does not have cancer.

% Consider a cancer test with the following characteristics:
% (i): TruePositiveRate = TPR = P(+|Cancer) = 0.90
% (ii): FalsePositiveRate = FPR = P(+|NoCancer) = 0.10

% Mind that the TPR indicates the probability of being tested positive 
% given that you do have cancer and FPR indicates the probability of being 
% tested positive given that you do not have cancer. Mind that TPR and FPR 
% do necessarily sum up to 1.

% In fact the following binary tree diagram recapitulates the previous
% information:
%
%                               (*)
%                               / \
%                              /   \
%                             /     \
%                            /       \
%                           /         \
%                          /           \
%                         /             \
%                     (Cancer)      (NoCancer)
%                       / \             / \
%                      /   \           /   \
%                     /     \         /     \
%                   (POS) (NEG)     (POS) (NEG)
%                     ||   ||         ||    ||
%                   [TPR] [FNR]     [FPR] [TNR]
%
% Apparently it holds that: TPR + FNR = 1 and TNR + FPR = 1

% We want to estimate the probability of one having cancer given that
% he/she has been tested positive, that is P(Cancer|+) = ?

% By utilizing Bayes updating rule we may write that:
%
%                P(+|Cancer) * P(Cancer)       TPR * Pc(0)
% P(Cancer|+) = --------------------------  = ------------  [1]
%                          P(+)                   P(+)
%
% But we may write that:
% P(+) = P(+|Cancer) * P(Cancer) + P(+|NoCancer) * P(NoCancer) ==>
% P(+) = TPR * Pc(0) + FPR * (1 - Pc(0)) [2]

% By combining Eqs. [1] and [2] we may write that:
%
%                         TPR * Pc(0)
% P(Cancer|+) = ------------------------------- ==>
%               TPR * Pc(0) + FPR * (1 - Pc(0))
%
%                      TPR * Pc(0)
% P(Cancer|+) = ------------------------- [3]
%               FPR + Pc(0) * (TPR - FPR)

% Pc(0) which is the a-priori probability of having cancer may be
% interpreted as the probability of having cancer after one has been tested
% positive in zero (0) tests. Accordignly, P(Cancer|+) may be interpreted
% as the conditional probability of having cancer after one has been tested
% positive in one (1) test. Thus, we may write that:
%
% P(Cancer|+) = Pc(1) [4]

% In this setting, Bayes rule provides an updating scheme in order to
% modify the probability that one has cancer after being tested positive to
% one cancer test more. Therefore, we may write that:
%
%                  TPR * Pc(0) 
% Pc(1) = -------------------------  [5]
%         FPR + Pc(0) * (TPR - FPR)

% Eq. [5] may be exploited to derive the more general updating rule for the
% probality that one has cancer after he has been tested positive in a
% sequence of (n) tests. Hence, we may write the general probability
% updating formula as:
%
%                  TPR * Pc(n-1) 
% Pc(n) = --------------------------- , for n>=1 [6]
%         FPR + Pc(n-1) * (TPR - FPR)

% Clear command window and workspace.
clc
clear
% Set the a-priori probability that one has cancer.
Pc = 0.01;
% Set the TPR and FPR of the cancer test.
TPR = 0.90;
FPR = 0.10;
% Set the number of tests in the sequence.
N = 20;
% Initialize a vector storing the sequence of probabilities.
P = zeros(1,N);
P(1) = Pc;
% Apply the probability updating rule given by Eq. [6].
for n = 2:N
    P(n) = (TPR * P(n-1)) / (FPR + P(n-1)*(TPR-FPR));
end
% Plot the vector of probabilities.
figure('Name','Bayes Updating Rule');
plot(1:N,P,'-b*','LineWidth',2.0);
grid on
