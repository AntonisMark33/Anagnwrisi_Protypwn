function [cluster_indices,clusters,cluster_centroids] = retrieve_clustering_information(Data,MaximumClusters,solution)

% This function retreives clustering related information given the
% clustering instance represented by solution.

Dimensionality = size(Data,2);

cluster_centroids = zeros(MaximumClusters,Dimensionality);
cluster_indices = cell(1,MaximumClusters);
clusters = cell(1,MaximumClusters);
for k = 1:1:MaximumClusters
    cluster_indices{k} = find(solution==k);
    clusters{k} = Data(cluster_indices{k},:);
    cluster_centroids(k,:) = mean(clusters{k});
end

