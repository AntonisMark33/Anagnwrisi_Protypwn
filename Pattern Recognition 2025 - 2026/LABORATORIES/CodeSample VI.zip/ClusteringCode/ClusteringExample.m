% This script demonstrates the hierarchical clustering algorithm on a set of
% artificially generated data points. Data points are considered to be
% sampled from three different multivariate distributions identified by the
% parameters MU1, MU2, MU3 and SIGMA1, SIGMA2, SIGMA3.

% Initialize workspace.
clc
clear

% Define the parameters of the multivariate gaussian distributions.
MU1 = [2 2];
MU2 = [6 6];
MU3 = [10 10];
MU4 = [14 14];

SIGMA1 = [1 0; 0 1];
SIGMA2 = [1 0; 0 1];
SIGMA3 = [1 0; 0 1];
SIGMA4 = [1 0; 0 1];

% Sample equal number of points from both distributions.
% Let N be the number of points to be sampled.
N = 200;
X1 = mvnrnd(MU1,SIGMA1,N);
X2 = mvnrnd(MU2,SIGMA2,N);
X3 = mvnrnd(MU3,SIGMA3,N);
X4 = mvnrnd(MU4,SIGMA4,N);
% Store both sets of points in a single matrix.
X = [X1;X2;X3;X4];

% Plot the labeded data points
figure('Name','Labeled Data Points')
hold on
plot(X1(:,1),X1(:,2),'*r','LineWidth',1.2);
plot(X2(:,1),X2(:,2),'*b','LineWidth',1.2);
plot(X3(:,1),X3(:,2),'*g','LineWidth',1.2);
plot(X4(:,1),X4(:,2),'*m','LineWidth',1.2);
xlabel('x1');
ylabel('x2');
grid on
hold off

%Plot the unlabaled data points.
figure('Name','Unlabeled Data Popints')
hold on
plot(X(:,1),X(:,2),'*k','LineWidth',1.2);
xlabel('x1');
ylabel('x2');
grid on
hold off

% Plot the distances' pdf for the complete data matrix.
% Set the number of intervals.
n = 150;
% Set the figure_name.
figure0_name = 'Complete Dataset Distances'' PDF';
[Do_min,Do_max,Do_mean] = distpdfplot(X,n,figure0_name);

% Plot the distances' pdf for the data points within the first cluster.
% Set the number of intervals.
n = 150;
% Set the figure_name.
figure1_name = 'Cluster 1 Dataset Distances'' PDF';
[D1_min,D1_max,D1_mean] = distpdfplot(X1,n,figure1_name);

% Plot the distances' pdf for the data points within the second cluster.
% Set the number of intervals.
n = 150;
% Set the figure_name.
figure2_name = 'Cluster 2 Dataset Distances'' PDF';
[D2_min,D2_max,D2_mean] = distpdfplot(X2,n,figure2_name);

% Plot the distances' pdf for the data points within the third cluster.
% Set the number of intervals.
n = 150;
% Set the figure_name.
figure3_name = 'Cluster 3 Dataset Distances'' PDF';
[D3_min,D3_max,D3_mean] = distpdfplot(X3,n,figure3_name);

% Plot the distances' pdf for the data points within the fourth cluster.
% Set the number of intervals.
n = 150;
% Set the figure_name.
figure4_name = 'Cluster 4 Dataset Distances'' PDF';
[D4_min,D4_max,D4_mean] = distpdfplot(X4,n,figure4_name);

% Perform agglomerative hierarchical clustering.
Y = pdist(X,'euclidean');
Z = linkage(Y,'average');
% Create and display the associated dendrogram.
figure('Name','Hierarchical Dendrogram')
[H,~] = dendrogram(Z,0,'colorthreshold','default');
set(H,'LineWidth',2)

% Perform k-means clustering into 4 clusters.
clusters_num = 4;
[clustering_solution,centroids] = kmeans(X,clusters_num,'distance','sqeuclidean','Replicates',5);
%Retrieve clustering information.
[cluster_indices,clusters,cluster_centroids] = retrieve_clustering_information(X,clusters_num,clustering_solution);
% Plot clusters' distribution.
plot_clusters(X,cluster_indices);

% Cluster data in three clusters.
T = clusterdata(X,'linkage','average',4);
figure('Name','Identified Clusters')
scatter(X(:,1),X(:,2),20,T,'filled')
grid on