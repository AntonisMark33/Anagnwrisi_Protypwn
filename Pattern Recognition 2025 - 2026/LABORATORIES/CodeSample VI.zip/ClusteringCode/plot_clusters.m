function plot_clusters(Data,cluster_indices)

% This function generates a 3-dimensional plot for the cluster distribution
% of a given dataset.

% Get the dimensionality of the data.
dimensionality = size(Data,2);

% Set all possible line specifiers in order to indicate distinct clusters.
MarkerSpecifiers = ['*','o','+','x','s','d'];
ColorSpecifiers = ['r','g','b','c','m','y','k'];
MarkerSpecifiersNum = length(MarkerSpecifiers);
ColorSpecifiersNum = length(ColorSpecifiers);
LineSpecifiersNum = MarkerSpecifiersNum * ColorSpecifiersNum;
LineSpecifiers = cell(1,LineSpecifiersNum);
line_specifier_index = 1;
for marker_specifier_index = 1:1:MarkerSpecifiersNum
    for color_specifier_index = 1:1:ColorSpecifiersNum
        LineSpecifiers{line_specifier_index} = strcat(MarkerSpecifiers(marker_specifier_index),ColorSpecifiers(color_specifier_index));
        line_specifier_index = line_specifier_index + 1;
    end
end

% Apply dimensionality reduction only when dimensionality is greater than
% 3.
if(dimensionality > 3)
    % Apply PCA to reduce data dimensionality.
    [~,Score] = pca(Data);
    ReducedData = Score(:,1:3);
else
    ReducedData = Data;
end
% Retrieve reduced data points per cluster.
MaximumClusters = length(cluster_indices);
clusters = cell(1,MaximumClusters);
for k = 1:1:MaximumClusters
    clusters{k} = ReducedData(cluster_indices{k},:);
end

% Create new figure.
figure('Name','Cluster Distribution');
% Perform different plotting operations depending on the dimensionality of
% the data points.
if(dimensionality >= 3)
    plot3(clusters{1}(:,1),clusters{1}(:,2),clusters{1}(:,3),LineSpecifiers{1});
    hold on
    for k = 2:1:MaximumClusters
        plot3(clusters{k}(:,1),clusters{k}(:,2),clusters{k}(:,3),LineSpecifiers{k});
    end
    grid on
    hold off
else
    hold on
    for k = 1:1:MaximumClusters
        plot(clusters{k}(:,1),clusters{k}(:,2),LineSpecifiers{k});
    end
    grid on
    hold off
end

end