function [Dmin,Dmax,Dmean] = distpdfplot(M,n,figure_name)

% This routine plots the pdf function of the distances between the elements
% of the data matrix M. dx represents the space interval.

NM = M;
%NM = get_normalized_matrix(M);
D = dist(NM,NM');
[R,L] = size(NM);
%D = D / sqrt(L);
% D = polykernel(NM,NM',3);
min_dist = min(min(D));
max_dist = max(max(D));
mean_dist = mean(reshape(D,1,numel(D)));
S = max_dist - min_dist;
dx = S / n;
f = zeros(1,n);
v_zeros = find(D==0);
f_zeros = length(v_zeros);
if(f_zeros > R)
    f_zeros = f_zeros - R;
end
for k = 1:1:n
    if(k == 1)
        vf = find(and((D>(k-1)*dx),(D<k*dx)));
    elseif(k == n)
        vf = find(and((D>=(k-1)*dx),(D<=k*dx)));
    else
        vf = find(and((D>=(k-1)*dx),(D<k*dx)));
    end
    f(k) = length(vf)/2;
end
f(1) = f(1) + f_zeros; %The frequency of zero values must be added in the first interval (0,dx)
x = 1:1:n;
x = x.*dx;
f = f / sum(f);
%subplot(2,1,1)
%plot(x,f,'-*r'),grid on
%subplot(2,1,2)
title_string = strcat(['D_{min} = ' num2str(min_dist) ' D_{max} = ' num2str(max_dist) ' D_{mean} = ' num2str(mean_dist)]);
figure('Name',figure_name);
bar(x,f,'r'),grid on
xlabel('Distance');
ylabel('Frequency');
title(title_string);
grid on
Dmin = min_dist;
Dmax = max_dist;
Dmean = min_dist;