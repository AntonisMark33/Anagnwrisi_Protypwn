function plot_cluster_centroids(cluster_centroids)

% This function plots the cluster centroids for each cluster.

% Set all possible line specifiers in order to indicate distinct clusters.
MarkerSpecifiers = ['*','o','+','x','s','d'];
ColorSpecifiers = ['r','g','b','c','m','y','k'];
MarkerSpecifiersNum = length(MarkerSpecifiers);
ColorSpecifiersNum = length(ColorSpecifiers);
LineSpecifiersNum = MarkerSpecifiersNum * ColorSpecifiersNum;
LineSpecifiers = cell(1,LineSpecifiersNum);
line_specifier_index = 1;
for marker_specifier_index = 1:1:MarkerSpecifiersNum
    for color_specifier_index = 1:1:ColorSpecifiersNum
        LineSpecifiers{line_specifier_index} = strcat(MarkerSpecifiers(marker_specifier_index),ColorSpecifiers(color_specifier_index));
        line_specifier_index = line_specifier_index + 1;
    end;
end;

[MaximumClusters,CentroidDimensionality] = size(cluster_centroids);
figure('Name','Cluster Centroids');
for k = 1:1:MaximumClusters
    subplot(MaximumClusters,1,k);
    stem([1:1:CentroidDimensionality],cluster_centroids(k,:),LineSpecifiers{k});
end;
